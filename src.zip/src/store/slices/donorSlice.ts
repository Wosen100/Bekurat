import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";

interface Donor {
  _id: string;
  fname: string;
  lName: string;
  email: string;
  postalCode: string;
}

interface DonorState {
  newDonor: Donor | null;
  createDonorLoading: string;
}

const initialState: DonorState = {
  newDonor: null,
  createDonorLoading: "idle",
};

export const createNewDonor = createAsyncThunk(
  "donor/create",
  async (donor: any) => {
    console.log(donor);
    const res = await axios.post("http://localhost:5001/donor/add", donor);
    return res.data.message.donor;
  }
);

export const DonorSlice = createSlice({
  name: "donor",
  initialState,
  reducers: {
    clearCreateDonorLoading: (state, action) => {
      state.createDonorLoading = "idle";
    },
  },
  extraReducers(builder) {
    builder.addCase(
      createNewDonor.fulfilled,
      (state, action: PayloadAction<Donor>) => {
        state.newDonor = action.payload;
        state.createDonorLoading = "completed";
      }
    );
    builder.addCase(createNewDonor.pending, (state, action) => {
      state.createDonorLoading = "loading";
    });
  },
});

export const { clearCreateDonorLoading } = DonorSlice.actions;

export default DonorSlice.reducer;
